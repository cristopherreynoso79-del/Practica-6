# Práctica 6 · Entornos virtuales y VS Code

Cristopher Cortés · IN1050 · Equipo A1

## Estado
Avance de la práctica. El cuaderno todavía no tiene salidas de ejecución ni respuestas a las tres preguntas finales. No está listo para la entrega final en Moodle.

## Archivos
- `demo.ipynb`: cuaderno original de Moodle con una celda adicional para comparar dos cargas del modelo.
- `mi-foto.jpg`: fotografía de Grogus proporcionada para la prueba.
- `requirements.txt`: versiones registradas en el entorno local.
- `.gitignore`: excluye `.venv` y archivos temporales.

## Ejecutar
En Git Bash, dentro de esta carpeta:

```bash
python -m venv .venv
source .venv/Scripts/activate
python -m pip install -r requirements.txt
code .
```

Abrir `demo.ipynb`, seleccionar el kernel `.venv`, ejecutar todas las celdas y responder las tres preguntas con los resultados observados. Guardar el cuaderno y subir la versión ejecutada. No subir `.venv`.

La prueba del equipo A1 se prepara por separado; no está incluida en esta carpeta individual.
